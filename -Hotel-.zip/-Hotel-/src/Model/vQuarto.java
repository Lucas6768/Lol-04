/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author lucas
 */
public class vQuarto {
    private int id_quarto;
    private String nome;
    private String preco;
    private String estado;
    private String tipo;

    public vQuarto(int id_quarto, String nome, String preco, String estado, String tipo) {
        this.id_quarto = id_quarto;
        this.nome = nome;
        this.preco = preco;
        this.estado = estado;
        this.tipo = tipo;
       
    }
    public vQuarto(){
    }

    public int getId_quarto() {
        return id_quarto;
    }

    public void setId_quarto(int id_quarto) {
        this.id_quarto = id_quarto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
}