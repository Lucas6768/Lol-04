<?php
session_start();
if(isset($_SESSION['id'])==0 and isset($_SESSION['nome'])==0){
	echo"<script>window.location='login.php'</script>";
	}else{
		$id=$_SESSION['id'];
		$nome=$_SESSION['nome'];
		echo"<h3> usuário:$nome <a href='logout.php'> sair </a> </h3>";
	}
	?>

<html>
<head>
	<style>
		body{
			font-family: Arial;
			background-color: #e3e3e3;
		}

		table{
			background-color: #d8bfd8;
		}
		#caixa1{
			background-color: #d8bfd8;
		}

		#caixa2{
			background-color: #d8bfd8;
		}

		#ca{
			background-color: #FFC0CB;
		}

		#tex{
			text-align: center;
			padding-left: 12px;
		}
		#ca{
  margin-top: -50;
		}
		#id2{
  margin-top: 50;
		}

	</style>
</head>
<body>
	<center>
<table border="1" id='ca'>
<thead>
	<th>
	
	 <h1> Agenda </h1>
 <form action="evento.php?cadastro=true" method="POST">
 	<label> produto: </label>
 	<input type="text" value="" id='caixa1' name="nome">
 	<p> </p>
 	<label> preco: </label>
 	<input type="text" value="" id='caixa2' name="preco">
 	<p> </p>
 	<input type="submit" value="cadastrar" >
 </form>	</th></thead></center>

 <center>
 	<p></p>
 	<p></p>
<table border="1" id="id2">

<thead>
	<tr id="tex">Lista</tr>
<tr>
	<th> Id </th>
	<th> produto </th>
	<th> preco</th>
	<th>funcionario</th>
	<th> Editar </th>
	<th> Excluir </th>
</tr>
</th>
</thead>


<?php 
include_once"conexao.php";
$sql="select p.codigo, p.nome as np, p.preco, c.nome as nf from funcionario as c join produto as p on c.id_funcionario=p.id_funcionario";
$result=mysql_query($sql,$con);
if($result){
	while($linha=mysql_fetch_array($result)){
	
		?>
		<tbody>
			<tr>
				<td> <?php echo $linha['codigo'];
				?> </td>
				<td><?php echo $linha['np'];?></td>
				<td><?php echo "R$ ".$linha['preco'];?></td>
             
				<td><?php echo $linha['nf']; ?></td>
				<td><?php echo "<a href=editar.php?editar=".$linha['codigo']."> editar </a>";
				?>
			</td>
			<td><?php echo "<a href=evento.php?deletar=".$linha['codigo']."> excluir </a> "

			?>
			</td>
		</tr>
	</tbody>
	<?php 
	}
}
mysql_close($con);
?>
</table>
</center>

</body>
</html>