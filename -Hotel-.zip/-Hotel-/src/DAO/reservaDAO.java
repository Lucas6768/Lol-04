/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.vGerente;
import Model.vReserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucas
 */
public class reservaDAO {
     
   private Conexao mysql=new Conexao();
   private Connection cn=mysql.conectar();
   private String sSQL="";
   public Integer totalregistros;
   
   
   public DefaultTableModel mostrar(String buscar){
       DefaultTableModel modelo;
       
       String [] titulos = {"Código","Código Quarto","Nome","Código Cliente","Cliente","Código Funcionário","Funcionário","Data Reserva","Data Entrada","Data Saída","Custo","Estado","id_reserva"};
       
       String [] registro =new String [13];
       
       totalregistros=0;
       modelo = new DefaultTableModel(null,titulos);
       
       sSQL="SELECT r.id_reserva,s.nome as nomeq, re.nome as nomere, h.nome as nomeh, r.entrada,r.saida , r.data_reserva, r.custo, r.estado "
            + "FROM reserva r "
            + "INNER JOIN quartos s "
            + "ON r.id_quarto =  s.id_quarto "
            + "INNER JOIN hospede h "
            + "ON r.id_hosp = h.id_hosp "
            + "INNER JOIN recepcionista re "
            + "ON r.id_recep = re.id_recep ";
           
       try {
           Statement st= cn.createStatement();
           ResultSet rs=st.executeQuery(sSQL);
           
           while(rs.next()){
               registro [0]=rs.getString("nomeq");  
               registro [1]=rs.getString("nomeh");
               registro [2]=rs.getString("nomere");
               registro [3]=rs.getString("data_reserva");
               registro [4]=rs.getString("entrada");
               registro [5]=rs.getString("saida");
               registro [6]=rs.getString("custo");
               registro [7]=rs.getString("estado");
               registro [8]=rs.getString("id_reserva");
//               
//               registro [3]=rs.getString("id_hosp");
////              registro [4]=rs.getString("clienten");
////               registro [5]=rs.getString("id_recep");
////               registro [6]=rs.getString("funcionarion");
////               registro [7]=rs.getString("data_reserva");
////               registro [8]=rs.getString("entrada");
////               registro [9]=rs.getString("saida");
////               registro [10]=rs.getString("custo");
////               registro [11]=rs.getString("estado");
               
               totalregistros=totalregistros+1;
               modelo.addRow(registro);
               
           }
           return modelo;
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return null;
       }
       
       
       
   } 


       
  
   public boolean insertar (vReserva dts){
       sSQL="insert into reserva (data_reserva,entrada,saida,custo,estado, id_quarto, id_hosp, id_recep)" +
               "values (?,?,?,?,?,?,?,?)";
       try {  
           vGerente g =  new vGerente();    
           PreparedStatement pst=cn.prepareStatement(sSQL);
           pst.setString(1, dts.getData_reserva());
           pst.setString(2, dts.getEntrada());
           pst.setString(3, dts.getSaida());
           pst.setDouble(4, dts.getCusto());
           pst.setString(5, dts.getEstado());
           pst.setInt(6, dts.getId_quarto());
           pst.setInt(7, dts.getId_hosp());
           pst.setInt(8, g.getId_recepcionista());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
           
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
   
   public boolean editar (vReserva dts){
       sSQL="update reserva set data_reserva=?,entrada=?,saida=?,custo=?,estado=?"+
               " where id_reserva=?";
           
       
       try {
           PreparedStatement pst=cn.prepareStatement(sSQL);
           
           pst.setString(1, dts.getData_reserva());
           pst.setString(2, dts.getEntrada());
           pst.setString(3, dts.getSaida());
           pst.setDouble(4, dts.getCusto());
           pst.setString(5, dts.getEstado());
           
           
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
   
   public boolean pagar (vReserva dts){
       sSQL="update reserva set estado='Paga'"+
               " where id_reserva=?";
           //alt + 39
       
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
             
           
           pst.setInt(1, dts.getId_reserva());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
   
   
   
   
   
  
   public boolean eliminar (vReserva dts){
       sSQL="delete from reserva where id_reserva=?";
       
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
           
           pst.setInt(1, dts.getId_reserva());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
}