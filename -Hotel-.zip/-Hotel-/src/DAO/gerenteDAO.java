/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.vGerente;
import Model.vHospede;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucas
 */
public class gerenteDAO {
     Connection con;
     private String sSQL="";

    public gerenteDAO() {
         con=Conexao.conectar();
    }
    public DefaultTableModel mostrar(String buscar){
       DefaultTableModel modelo;
       
       String [] titulos = {"Id","Nome","Telefone","Email","Cpf","Endereço","Login","Senha"};
       
       String [] registro =new String [8];
       
      
       modelo = new DefaultTableModel(null,titulos);
       
       sSQL="select * from gerente where nome like '%"+ buscar + "%' order by id_geren";
       
       try {
           Statement st= con.createStatement();
           ResultSet rs=st.executeQuery(sSQL);
           
           while(rs.next()){
               registro [0]=rs.getString("id_geren");
               registro [1]=rs.getString("nome");
               registro [2]=rs.getString("telefone");
               registro [3]=rs.getString("email");
               registro [4]=rs.getString("cpf");
               registro [5]=rs.getString("endereço");
               registro [6]=rs.getString("login");
               registro [7]=rs.getString("senha");
             
               modelo.addRow(registro);
               
           }
           return modelo;
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return null;
       }
     } 
     
    public boolean inserir_Geren(vGerente dts) {
    sSQL="insert into gerente(nome,login,senha,telefone,cpf,endereço,email,id_admin) "
                + "values (?,?,?,?,?,?,?,?) ";
        try {
       vHospede o = new vHospede();
        PreparedStatement ps=con.prepareStatement(sSQL);
       
        ps.setString(1,dts.getNome());
        ps.setString(2,dts.getLogin());
        ps.setString(3,dts.getSenha());
        ps.setString(4,dts.getTelefone());
        ps.setString(5,dts.getCpf());
        ps.setString(6,dts.getEndereco());
        ps.setString(7,dts.getEmail());
        ps.setInt(8,o.getId_admin());
       int n=ps.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
        
    }catch(SQLException ex){
         JOptionPane.showConfirmDialog(null, ex);
         return false;
    }
}


  
    
    public boolean excluir_Geren (vGerente p){
        try{
        PreparedStatement ps = con.prepareStatement(" DELETE FROM gerente WHERE id_geren=?");
        ps.setInt(1,p.getId_geren());
       int n=ps.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
        
        }catch (SQLException ex){
System.out.println(ex);
return false;
 }finally{
        Conexao.fecharConexao(con);
    }
    }
    
    
    public boolean atualizar_Geren(vGerente p){
    try {
        PreparedStatement ps=con.prepareStatement("UPDATE gerente SET nome=?,login=?,senha=?,telefone=?,cpf=?,endereço=?,email=?"
                + " WHERE id_geren=?");
        ps.setString(1,p.getNome());
        ps.setString(2,p.getLogin());
        ps.setString(3,p.getSenha());
        ps.setString(4,p.getTelefone());
        ps.setString(5,p.getCpf());
        ps.setString(6,p.getEndereco());
        ps.setString(7,p.getEmail());
         ps.setInt(8,p.getId_geren());
        ps.executeUpdate();
        int n=ps.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
    }catch(SQLException ex){
        System.out.println(ex);
        return false;
    }finally{
        Conexao.fecharConexao(con);
    }
}

   public List<vGerente> buscar(){
        List<vGerente> listar1 = new ArrayList<>();
    try{
    PreparedStatement ps = con.prepareStatement(" SELECT * FROM gerente");
 ResultSet rs = ps.executeQuery();
 while(rs.next()){
     vGerente p = new vGerente();
     p.setNome(rs.getString("nome"));
    
     listar1.add(p);
 }
}catch (SQLException ex){
System.out.println(ex);
 }finally{
        Conexao.fecharConexao(con);
    }
    return listar1;
    }
    
    
}