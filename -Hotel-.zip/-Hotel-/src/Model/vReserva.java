/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author lucas
 */
public class vReserva {

    private int id_reserva;
    private int id_quarto;
    private int id_hosp;
    private int id_recep;
    private String data_reserva;
    private String entrada;
    private String saida;
    private Double custo;
    private String estado;

    public vReserva() {
    }

    public vReserva(int id_reserva, int id_quarto, int id_hosp, int id_recep, String data_reserva, String entrada, String saida, Double custo, String estado) {
        this.id_reserva = id_reserva;
        this.id_quarto = id_quarto;
        this.id_hosp = id_hosp;
        this.id_recep = id_recep;
        this.data_reserva = data_reserva;
        this.entrada = entrada;
        this.saida = saida;
        this.custo = custo;
        this.estado = estado;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public int getId_quarto() {
        return id_quarto;
    }

    public void setId_quarto(int id_quarto) {
        this.id_quarto = id_quarto;
    }

    public int getId_hosp() {
        return id_hosp;
    }

    public void setId_hosp(int id_hosp) {
        this.id_hosp = id_hosp;
    }

    public int getId_recep() {
        return id_recep;
    }

    public void setId_recep(int id_recep) {
        this.id_recep = id_recep;
    }

    public String getData_reserva() {
        return data_reserva;
    }

    public void setData_reserva(String data_reserva) {
        this.data_reserva = data_reserva;
    }

    public String getEntrada() {
        return entrada;
    }

    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }

    public String getSaida() {
        return saida;
    }

    public void setSaida(String saida) {
        this.saida = saida;
    }

    public Double getCusto() {
        return custo;
    }

    public void setCusto(Double custo) {
        this.custo = custo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    

    
    
}

