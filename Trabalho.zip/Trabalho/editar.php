<html>
<head>
<meta charset="utf-8"/>
<style>
		body{
			font-family: Arial;
			background-color: #e3e3e3;
		}
		table{
			background-color: #FFC0CB;
		}

		#caixa1{
			background-color: #d8bfd8;
		}

		#caixa2{
			background-color: #d8bfd8;
		}
	</style>
</head>
<body>
<?php
include_once'conexao.php';
$sql='select * from produto where codigo='.$_GET['editar'];
$result=mysql_query($sql,$con);
$linha=mysql_fetch_array($result);
?>
<center>
<table border="1">
<thead>
	<th>
<h3><font color='white'> Editar contato</font> </h3> 
<?php echo"<form action='evento.php?editar=".$linha['codigo']."'method='POST'>";?>
produto: <input type="text" name="nome" id='caixa1' value="<?php echo $linha['nome'];?>"><p></p>
preco: <input type="text" name="preco" id='caixa2' value="<?php echo $linha['preco'];?>"><p></p>
<input type="submit" value="Editar">
</form>
</th></thead></center>
</body>
</html> 