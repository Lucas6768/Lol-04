/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author brock
 */
public class vHospede {
     private int id_hosp;
    private String nome;
    private String login;
    private String senha;
    private String rg;
    private String email;
    private String telefone;
    private String endereço;
    private String cpf;
    static int id_admin;

    public vHospede() {
    }

    public vHospede(int id_hosp, String nome, String login, String senha, String rg, String email, String telefone, String endereço, String cpf) {
        this.id_hosp = id_hosp;
        this.nome = nome;
        this.login = login;
        this.senha = senha;
        this.rg = rg;
        this.email = email;
        this.telefone = telefone;
        this.endereço = endereço;
        this.cpf = cpf;
    }

    public int getId_admin() {
        return id_admin;
    }

    public void setId_admin(int id_admin) {
        this.id_admin = id_admin;
    }


    public int getId_hosp() {
        return id_hosp;
    }

    public void setId_hosp(int id_hosp) {
        this.id_hosp = id_hosp;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

   
}
