/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.vHospede;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author brock
 */
public class hospedeDAO {
    private Conexao mysql=new Conexao();
   private Connection cn=mysql.conectar();
   private String sSQL="";
   public Integer totalregistros;
   
   
   public DefaultTableModel mostrar(String buscar){
       DefaultTableModel modelo;
       
       String [] titulos = {"Id","Nome","Cpf","Rg","Login","Senha","Endereço","E-mail","Telefone"};
       
       String [] registro =new String [9];
       
       totalregistros=0;
       modelo = new DefaultTableModel(null,titulos);
       
       sSQL="select * from hospede where nome like '%"+ buscar + "%' order by id_hosp";
       
       try {
           Statement st= cn.createStatement();
           ResultSet rs=st.executeQuery(sSQL);
           
           while(rs.next()){
               registro [0]=rs.getString("id_hosp");
               registro [1]=rs.getString("nome");
               registro [2]=rs.getString("cpf");
               registro [3]=rs.getString("rg");
               registro [4]=rs.getString("login");
               registro [5]=rs.getString("senha");
               registro [6]=rs.getString("endereço");
               registro [7]=rs.getString("email");
               registro [8]=rs.getString("telefone");
               totalregistros=totalregistros+1;
               modelo.addRow(registro);
               
           }
           return modelo;
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return null;
       }
     } 
   
    
 
   
   
   
   
   
   
   
   
   
   
   
   
   public boolean insertar (vHospede dts){
       sSQL="insert into hospede (nome,cpf,rg,login,senha,endereço,email,telefone)" +
               "values (?,?,?,?,?,?,?,?)";
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
           pst.setString(1, dts.getNome());
           pst.setString(2, dts.getCpf());
           pst.setString(3, dts.getRg());
           pst.setString(4, dts.getLogin());
           pst.setString(5, dts.getSenha());
           pst.setString(6, dts.getEndereço());
           pst.setString(7, dts.getEmail());
           pst.setString(8, dts.getTelefone());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
           
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
   
   public boolean editar (vHospede dts){
       sSQL="UPDATE hospede set nome=?,cpf=?,rg=?,login=?,senha=?,endereço=?,email=?,telefone=?"+
               " where id_hosp=?";
           
       
       try {
           PreparedStatement pst=cn.prepareStatement(sSQL);
           pst.setString(1, dts.getNome());
           pst.setString(2, dts.getCpf());
           pst.setString(3, dts.getRg());
           pst.setString(4, dts.getLogin());
           pst.setString(5, dts.getSenha());
           pst.setString(6, dts.getEndereço());
           pst.setString(7, dts.getEmail());
           pst.setString(8, dts.getTelefone());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   } 
  
  
   
   

   
   
   public boolean eliminar (vHospede dts){
       sSQL="delete from hospede where id_hosp=?";
       
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
           
           pst.setInt(1, dts.getId_hosp());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
}
