/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author brock
 */
public class vPagamento {
    private int id_pag;
    private String tipo_comprovante;
    private String total_pagamento;
    private String data_pagamento;

    public vPagamento() {
    }

    public vPagamento(int id_pag, String tipo_comprovante, String total_pagamento, String data_pagamento) {
        this.id_pag = id_pag;
        this.tipo_comprovante = tipo_comprovante;
        this.total_pagamento = total_pagamento;
        this.data_pagamento = data_pagamento;
    }

    public int getId_pag() {
        return id_pag;
    }

    public void setId_pag(int id_pag) {
        this.id_pag = id_pag;
    }

    public String getTipo_comprovante() {
        return tipo_comprovante;
    }

    public void setTipo_comprovante(String tipo_comprovante) {
        this.tipo_comprovante = tipo_comprovante;
    }

    public String getTotal_pagamento() {
        return total_pagamento;
    }

    public void setTotal_pagamento(String total_pagamento) {
        this.total_pagamento = total_pagamento;
    }

    public String getData_pagamento() {
        return data_pagamento;
    }

    public void setData_pagamento(String data_pagamento) {
        this.data_pagamento = data_pagamento;
    }
    
}
