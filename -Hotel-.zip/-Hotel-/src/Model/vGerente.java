/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author lucas
 */
public class vGerente {
    String nome;
    String login;
    String senha;
    String telefone;
    String cpf;
    String endereco;
    String email; 
    int id_geren;
    int id_admin;
   static int id_recepcionista;
    

    public vGerente() {
        nome= "";
        login= "";
        senha= "";
        telefone= "";
        cpf= "";
        endereco= "";
        email="";
    
    }

    public int getId_recepcionista() {
        return id_recepcionista;
    }

    public void setId_recepcionista(int id_recepcionista) {
        this.id_recepcionista = id_recepcionista;
    }
    
    

    public int getId_admin() {
        return id_admin;
    }

    public void setId_admin(int id_admin) {
        this.id_admin = id_admin;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId_geren() {
        return id_geren;
    }

    public void setId_geren(int id_geren) {
        this.id_geren = id_geren;
    }
}

