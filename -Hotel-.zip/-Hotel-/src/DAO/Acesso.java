/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.vGerente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class Acesso {
    Connection con;
    
    public Acesso() {
    con=Conexao.conectar();
         
    }
    public boolean LogarAdm(String login, String senha){
    boolean finalResult= false;
    try{
    String consulta= "select login, senha from administrador where login='" + login + "' and senha ='" + senha + "'";
    PreparedStatement ps= con.prepareStatement(consulta);
    ResultSet rs = ps.executeQuery();
    if(rs != null){
    while(rs.next()){
    finalResult= true;
    }//final do while
    }//final do if
    }catch (SQLException ex){
    ex.getMessage();
    }//final do catch
    return finalResult;
    
    }//final do logar
    public boolean LogarGerente(String login, String senha){
    boolean finalResult= false;
    try{
    String consulta= "select login, senha from gerente where login='" + login + "' and senha ='" + senha + "'";
    PreparedStatement ps= con.prepareStatement(consulta);
    ResultSet rs = ps.executeQuery();
    if(rs != null){
    while(rs.next()){
    finalResult= true;
    }//final do while
    }//final do if
    }catch (SQLException ex){
    ex.getMessage();
    }//final do catch
    return finalResult;
    
    }
    public boolean LogarRecepcionista(String login, String senha){
    boolean finalResult= false;
    try{
          
    String consulta= "select id_recep,login, senha from recepcionista where login='" + login + "' and senha ='" + senha + "'";
    PreparedStatement ps= con.prepareStatement(consulta);
    ResultSet rs = ps.executeQuery(); 
  
    if(rs != null){
        


           
    while(rs.next()){
          
    finalResult= true;
    
   vGerente g =  new vGerente();    
      g.setId_recepcionista(rs.getInt("id_recep"));
      
         
    
    }//final do while
    }//final do if
    }catch (SQLException ex){
    ex.getMessage();
    }//final do catch
    return finalResult;
    
    }
}
