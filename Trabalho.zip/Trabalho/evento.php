<?php session_start(); ?>
<?php

include_once'conexao.php';
if(isset($_POST['nome']))$atrnome=$_POST['nome'];
if(isset($_POST['preco']))$atrpreco=$_POST['preco'];
if(isset($_GET['cadastro'])){
	$sql="insert into produto values(0,'".$atrnome."','".$atrpreco."',1)";
	mysql_query($sql,$con);
	echo"<script> alert('produto cadastrado com sucesso') </script>";
}
  if(isset($_GET['deletar'])){
  $sql="delete from produto where codigo=".$_GET['deletar'];
  mysql_query($sql,$con);
  echo"<script> alert('produto deletado com sucesso') </script>";
}

if(isset($_GET['editar'])) {
  $sql="update produto SET nome='".$atrnome."',preco='".$atrpreco."' where codigo=".$_GET['editar'];
  mysql_query($sql,$con);
 // echo $sql;
  echo"<script> alert('produto atualizado com sucesso') </script>";

 }
 
echo"<script>window.location='index.php'</script>";

?>