/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author lucas
 */
public class vConsumo {
    
    private int id_consumo;
    private int id_reserva;
    private int id_serv;
    private Double quantidade;
    private Double preco;
    private String estado;

    public vConsumo() {
    }

    public vConsumo(int id_consumo, int id_reserva, int id_serv, Double quantidade, Double preco, String estado) {
        this.id_consumo = id_consumo;
        this.id_reserva = id_reserva;
        this.id_serv = id_serv;
        this.quantidade = quantidade;
        this.preco = preco;
        this.estado = estado;
    }

    public int getId_consumo() {
        return id_consumo;
    }

    public void setId_consumo(int id_consumo) {
        this.id_consumo = id_consumo;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public int getId_serv() {
        return id_serv;
    }

    public void setId_serv(int id_serv) {
        this.id_serv = id_serv;
    }

    public Double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Double quantidade) {
        this.quantidade = quantidade;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
