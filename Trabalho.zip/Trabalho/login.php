<html>
<head>
<meta charset='utf-8'>
</head>
<body> <center>
<p> contato </p>
<form method="post" action="">
login:
<input type="text" name="login"> <br> <br>
senha:
<input type="password"  name="senha">
<p> </p>
<input type="submit" value="entrar"> 
</form>

<?php
include_once"conexao.php";
if(isset($_POST['login'])==0 and isset($_POST['senha'])==0){
	echo "<script>alert('login ou senha invalidas')</script";
}else{
$login=$_POST['login'];
$senha=$_POST['senha'];
$sql="select * from funcionario where nome='$login' and senha='$senha'";
$result=mysql_query($sql,$con);
$res=mysql_num_rows($result);
if($res){
	$linha=mysql_fetch_array($result);
	session_start();
	$_SESSION["id"]=$linha['id_funcionario'];
	$_SESSION["nome"]=$linha['nome'];
	echo"<script> window.location='index.php' </script>";

}}

?>

</body>
</html>

