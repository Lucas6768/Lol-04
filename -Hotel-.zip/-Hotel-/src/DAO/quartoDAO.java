/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.vQuarto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucas
 */
public class quartoDAO {
    
   private Conexao mysql=new Conexao();
   private Connection cn=mysql.conectar();
   private String sSQL="";
   public Integer totalregistros;
   
   
   public DefaultTableModel mostrar(String buscar){
       DefaultTableModel modelo;
       
       String [] titulos = {"Id","Nome","Preco","Estado","Tipo"};
       
       String [] registro =new String [5];
       
       totalregistros=0;
       modelo = new DefaultTableModel(null,titulos);
       
       sSQL="select * from quartos where nome like '%"+ buscar + "%' order by id_quarto";
       
       try {
           Statement st= cn.createStatement();
           ResultSet rs=st.executeQuery(sSQL);
           
           while(rs.next()){
               registro [0]=rs.getString("id_quarto");
               registro [1]=rs.getString("nome");
               registro [2]=rs.getString("preco");
               registro [3]=rs.getString("estado");
               registro [4]=rs.getString("tipo");
               
               totalregistros=totalregistros+1;
               modelo.addRow(registro);
               
           }
           return modelo;
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return null;
       }
     } 
   
    
    public DefaultTableModel mostrarKO(String buscar){
       DefaultTableModel modelo;
       
       String [] titulos = {"Id","Nome","Preco","Estado","Tipo"};
       
       String [] registro =new String [5];
       
       totalregistros=0;
       modelo = new DefaultTableModel(null,titulos);
       
       sSQL="select * from quartos where nome like '%"+ buscar + "%' and estado='Disponível' order by id_quarto";
       
       try {
           Statement st= cn.createStatement();
           ResultSet rs=st.executeQuery(sSQL);
           
           while(rs.next()){
               registro [0]=rs.getString("id_quarto");
               registro [1]=rs.getString("nome");
               registro [2]=rs.getString("preco");
               registro [3]=rs.getString("estado");
               registro [4]=rs.getString("tipo");
               
               totalregistros=totalregistros+1;
               modelo.addRow(registro);
               
           }
           return modelo;
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return null;
       }
     } 
   
 
   
   
   
   
   
   
   
   
   
   
   
   
   public boolean insertar (vQuarto dts){
       sSQL="insert into quartos (nome,preco,estado,tipo)" +
               "values (?,?,?,?)";
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
           pst.setString(1, dts.getNome());
           pst.setString(2, dts.getPreco());
           pst.setString(3, dts.getEstado());
           pst.setString(4, dts.getTipo());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
           
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
   
   public boolean editar (vQuarto dts){
       sSQL="UPDATE quartos set nome=?,preco=?,estado=?,tipo=?"+
               " where id_quarto=?";
           
       
       try {
           PreparedStatement pst=cn.prepareStatement(sSQL);
           pst.setString(1, dts.getNome());
           pst.setString(2, dts.getPreco());
           pst.setString(3, dts.getEstado());
           pst.setString(4, dts.getTipo());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   } 
  
  /* public boolean desocupar (vHabitacao dts){
       sSQL="update habitacao set estado='Disponivel'"+
               " where cod_habitacao=?";
           //alt + 39
       
       try {
           PreparedStatement pst=cn.prepareStatement(sSQL);
          
           pst.setInt(1, dts.getCod_habitacao());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
 
    */
   
   public boolean ocupar (vQuarto dts){
       sSQL="update quartos set estado='Ocupado'"+
               " where id_quarto=?";

       
       try {
           PreparedStatement pst=cn.prepareStatement(sSQL);
          
           pst.setInt(1, dts.getId_quarto());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   } 
  

   
   
   public boolean eliminar (vQuarto dts){
       sSQL="delete from quartos where id_quarto=?";
       
       try {
           
           PreparedStatement pst=cn.prepareStatement(sSQL);
           
           pst.setInt(1, dts.getId_quarto());
           
           int n=pst.executeUpdate();
           
           if (n!=0){
               return true;
           }
           else {
               return false;
           }
           
       } catch (Exception e) {
           JOptionPane.showConfirmDialog(null, e);
           return false;
       }
   }
}
